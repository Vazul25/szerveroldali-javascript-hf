var DebtState;
(function (DebtState) {
    DebtState[DebtState["UnSetteled"] = 0] = "UnSetteled";
    DebtState[DebtState["UnApproved"] = 1] = "UnApproved";
    DebtState[DebtState["Approved"] = 2] = "Approved";
})(DebtState || (DebtState = {}));
