interface iUser{
    id:number;
    fullName:string;
    nickName:string;
    email:string;
    birthDay:Date;

}