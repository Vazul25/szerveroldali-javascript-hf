"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//Létrehozza az új tartozásokat
module.exports = function (objectRepository) {
    return function (req, res, next) {
        //
        //objectRepository['db'].update
        return next();
    };
};
