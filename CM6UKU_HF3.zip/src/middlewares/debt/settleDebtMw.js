"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//Továbbítja jóváhagyásra a rendezést,
module.exports = function (objectRepository) {
    return function (req, res, next) {
        //
        //objectRepository['db'].update
        return next();
    };
};
