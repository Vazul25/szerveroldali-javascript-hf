"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//login ellenőrzés
module.exports = function (objectRepository) {
    return function (req, res, next) {
        return next();
    };
};
