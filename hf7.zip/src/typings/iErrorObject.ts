interface iErrorObject{

    errorMessage:string;
    errorCode:number;


}