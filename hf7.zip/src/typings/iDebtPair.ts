import {iDebt} from "../model_Interfaces/iDebt";

export interface iDebtPair{

    debtsToMe:iDebt[];
    myDebts:iDebt[];


}